# GCP Cloud Functions Repository

This repository contains Google Cloud Functions and Workflows for various processing tasks.

## Structure

- `cloud-functions/` - Individual Cloud Function implementations
- `workflows/` - Google Cloud Workflows definitions
- `environments/` - Environment-specific configurations
- `scripts/` - Deployment scripts
- `.github/workflows/` - CI/CD pipelines

## Deployment

Use the deployment scripts:
```bash
./scripts/deploy.sh dev short-on-truck
./scripts/workflow-deploy.sh dev short-on-truck
```

## Environments

- **dev** - Development environment
- **test** - Testing environment  
- **prod** - Production environment