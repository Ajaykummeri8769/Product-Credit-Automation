#!/bin/bash
ENV=${1:-dev}
FUNCTION_NAME=${2:-short-on-truck}

echo "Deploying $FUNCTION_NAME to $ENV environment"

gcloud functions deploy $FUNCTION_NAME \
  --source=cloud-functions/$FUNCTION_NAME \
  --entry-point=$FUNCTION_NAME \
  --runtime=python311 \
  --trigger=http \
  --allow-unauthenticated \
  --env-vars-file=environments/$ENV/secrets.env