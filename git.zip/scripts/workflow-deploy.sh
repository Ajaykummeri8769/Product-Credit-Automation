#!/bin/bash
ENV=${1:-dev}
WORKFLOW_NAME=${2:-short-on-truck}

echo "Deploying workflow $WORKFLOW_NAME to $ENV environment"

gcloud workflows deploy $WORKFLOW_NAME \
  --source=workflows/$WORKFLOW_NAME.yaml \
  --location=us-central1